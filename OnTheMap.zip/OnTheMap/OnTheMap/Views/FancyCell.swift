//
//  FancyCell.swift
//  OnTheMap
//
//  Created by Raneem on 5/8/19.
//  Copyright © 2019 Raneem. All rights reserved.
//

import UIKit

class FancyCell: UITableViewCell {

    @IBOutlet weak var cellImage: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var urlLabel: UILabel!
    
    
    func configWith(_ info: StudentLocation) {
        nameLabel.text = info.firstName
        urlLabel.text = info.mediaURL
    }
    
}
