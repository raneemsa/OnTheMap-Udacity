//
//  UdacityPOSTSessionResponse.swift
//  OnTheMap
//
//  Created by Raneem on 5/8/19.
//  Copyright © 2019 Raneem. All rights reserved.
//

import Foundation

struct UdacityPOSTSessionResponse: Codable {
    
    let account: Account?
    let session: Session?
    
    struct Account: Codable {
        
        let registered: Bool?
        let key: String?
    }
    
    struct Session: Codable {
        let id: String?
        let sessionExpiration: String?
    }
    
}
