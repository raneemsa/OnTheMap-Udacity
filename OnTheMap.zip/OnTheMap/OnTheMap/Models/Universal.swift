//
//  Universal.swift
//  OnTheMap
//
//  Created by Raneem on 5/16/19.
//  Copyright © 2019 Ahmed Osama. All rights reserved.
//

import UIKit

class Universal {
    
    
      static let shared=Universal()
    
      var studentLocations:[StudentLocation]?
    
    



    }
    



