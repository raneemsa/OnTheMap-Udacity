//
//  StudentLocationPOSTResponse.swift
//  OnTheMap
//
//  Created by Raneem on 5/8/19.
//  Copyright © 2019 Raneem. All rights reserved.
//

import Foundation

struct StudentLocationPOSTResponse: Codable {
    let createdAt: String?
    let objectId: String?
}
