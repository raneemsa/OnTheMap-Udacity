//
//  ParseClient.swift
//  OnTheMap
//
//  Created by Raneem on 5/8/19.
//  Copyright © 2019 Raneem. All rights reserved.
//

import Foundation

class ParseClient {
    
    private static let appID = "QrX47CA9cyuGewLdsL7o5Eb8iug6Em8ye0dnAbIr"
    private static let apiKey = "QuWThTdiRmTux3YaDseUSEpUKo7aBYM737yKd4gY"
    private static let endpointURL = URL(string: "https://parse.udacity.com/parse/classes/StudentLocation")!
    
    static func GETStudentLocation(completionHandler: @escaping ([StudentLocation]?, String?) -> Void) {
        let limit = URLQueryItem(name: "limit", value: "100")
        let order = URLQueryItem(name: "order", value: "-updatedAt")
        var urlComponents = URLComponents(string: endpointURL.absoluteString)
        urlComponents?.queryItems = [limit, order]
        performGETStudentLocation(url: (urlComponents?.url)!, completionHandler: completionHandler)
    }
    
    static func GETStudentLocation(
        with userID: String,
        completionHandler: @escaping ([StudentLocation]?, String?) -> Void) {
        let url = endpointURL.appendingPathComponent("where={\"uniqueKey\":\"\(userID)\"}")
        print(url.absoluteString)
        performGETStudentLocation(url: url, completionHandler: completionHandler)
    }
    
    private static func performGETStudentLocation(
                            url: URL,
                            completionHandler: @escaping ([StudentLocation]?, String?) -> Void) {
        
        var request = URLRequest(url: url)
        request.allHTTPHeaderFields = ["X-Parse-Application-Id": ParseClient.appID,
                                       "X-Parse-REST-API-Key": ParseClient.apiKey]
        Helpers.performDataTask(with: request, responseType: [String: [StudentLocation]].self, secured: false) {
            (response, message) in
            let cleanedResponse = response?["results"]
            completionHandler(cleanedResponse, message)
        }
    }
    
    static func POSTStudentLocation(
                    mapString: String, mediaURL: String,
                    latitude: Float, longitude: Float,
                    completionHandler: @escaping (StudentLocationPOSTResponse?, String?) -> Void) {
        
        POSTorPUTStudentLocation(url: endpointURL, method: "POST", mapString: mapString, mediaURL: mediaURL, latitude: latitude, longitude: longitude, completionHandler: completionHandler)
        
    }
    
    static func PUTStudentLocation(objectID: String,
                    mapString: String, mediaURL: String,
                    latitude: Float, longitude: Float,
                    completionHandler: @escaping (StudentLocationPUTResponse?, String?) -> Void) {
        
        let url = endpointURL.appendingPathComponent(objectID)
        POSTorPUTStudentLocation(url: url, method: "PUT", mapString: mapString, mediaURL: mediaURL, latitude: latitude, longitude: longitude, completionHandler: completionHandler)
        
    }
    
    
    private static func POSTorPUTStudentLocation<T: Decodable>(
                            url: URL,
                            method: String,
                            mapString: String, mediaURL: String,
                            latitude: Float, longitude: Float,
                            completionHandler:
                            @escaping (T?, String?) -> Void) {
        
        guard (T.self == StudentLocationPOSTResponse.self || T.self == StudentLocationPUTResponse.self)
              && (method == "POST" || method == "PUT") else {
                completionHandler(nil, "Internal local error: Invalid request.")
                return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = method
        
        request.allHTTPHeaderFields = ["X-Parse-Application-Id": ParseClient.appID,
                                       "X-Parse-REST-API-Key": ParseClient.apiKey,
                                       "Content-Type": "application/json"]
        
        let bodyJson: [String : Any] = ["uniqueKey": NetworkManager.Udacity.accountKey!,
                                        "firstName": (NetworkManager.Udacity.user?.firstName ?? ""),
                                        "lastName": (NetworkManager.Udacity.user?.lastName ?? ""),
                                        "mapString": mapString,
                                        "mediaURL": mediaURL,
                                        "latitude": latitude,
                                        "longitude": longitude]
        
        let bodyJsonData = try? JSONSerialization.data(withJSONObject: bodyJson)
        request.httpBody = bodyJsonData
        
        Helpers.performDataTask(with: request, responseType: T.self, secured: false,
                                completionHandler: completionHandler)
        
    }
    
}
