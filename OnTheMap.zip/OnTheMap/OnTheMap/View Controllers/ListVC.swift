//
//  ListVC.swift
//  OnTheMap
//
//  Created by Raneem on 5/8/19.
//  Copyright © 2019 Raneem. All rights reserved.
//

import UIKit

class ListVC: UIViewController {

    
    @IBOutlet weak var tableView: UITableView!
    
    let CellID = "FancyCell"
    
    override func viewDidLoad() {
        super.viewDidLoad()

        tableView.delegate = self
        tableView.dataSource = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        loadLocations()
    }
    
    
    @IBAction func refresh(_ sender: Any) {
        loadLocations()
    }
    
    
    @IBAction func logoutButtonClicked(_ sender: Any) {
        NetworkManager.Udacity.logout { (errorMessage) in
            if let error = errorMessage {
                Helpers.showAlertDialog(viewController: self,
                                        title: "Failure in Loggingout", message: error)
            }
            else {
                self.dismiss(animated: true, completion: nil)
            }
        }
    }

    func loadLocations() {
        NetworkManager.Parse.getUniqueStudentLocation(type: .allLocations) { (locations, errorMessage) in
            if let error = errorMessage {
                Helpers.showAlertDialog(viewController: self,
                                        title: "Failure to Get Locations", message: error)
            }
            else {
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            }
        }
    }
    
}

extension ListVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Universal.shared.studentLocations?.count ?? 0
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: CellID) as! FancyCell
        //let student = Universal.shared.studentLocations![indexPath.row])
        //cell.nameLabel.text = student.mapString
        //cell.urlLabel.text = student.mediaURL
        cell.configWith(Universal.shared.studentLocations![indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let index = indexPath
        tableView.deselectRow(at: indexPath, animated: true)
        if let link = Universal.shared.studentLocations?[index.row].mediaURL {
            let url = URL(string: link)
            if url != nil {
                UIApplication.shared.open(url!, options: [:], completionHandler: nil)
            }
        }
    }
    
}
