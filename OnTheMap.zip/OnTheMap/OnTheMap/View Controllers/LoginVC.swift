//
//  LoginVC.swift
//  OnTheMap
//
//  Created by Raneem on 5/8/19.
//  Copyright © 2019 Raneem. All rights reserved.
//


import UIKit

class LoginVC: UIViewController {
    
    let loginID = "loginSuccess"
    

    
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var signupButton: UIButton!
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        emailField.delegate = self
        passwordField.delegate = self
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        enableUI(true)
    }
    
    @IBAction func loginButtonClicked(_ sender: Any) {
        enableUI(false)
        NetworkManager.Udacity.login(username: emailField.text!,
            password: passwordField.text!) { (errorMessage) in
            if let errorMessage = errorMessage {
                self.enableUI(true)
                Helpers.showAlertDialog(viewController: self,
                                        title: "Failed to Login", message: errorMessage)
            }
            else {
                self.performSegue(withIdentifier: self.loginID, sender: self)
            }
        }
    }
    
    
    @IBAction func signupButtonClicked(_ sender: Any) {
        
        openWithSafari("https://auth.udacity.com/sign-up")
    }
    
    
    
    func enableUI(_ enabled: Bool) {
        DispatchQueue.main.async {
            self.emailField.isEnabled = enabled
            self.passwordField.isEnabled = enabled
            self.loginButton.isEnabled = enabled
            self.signupButton.isEnabled = enabled
        } }
    
        
        func openWithSafari(_ url: String) {
            
            guard let url = URL(string: url), UIApplication.shared.canOpenURL(url)
                else {
                    return
            }
            UIApplication.shared.open(url, options: [:])
    }
    
    
    
    
}

extension LoginVC: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}
