//
//  AddPinVC.swift
//  OnTheMap
//
//  Created by Raneem on 5/8/19.
//  Copyright © 2019 Raneem. All rights reserved.
//

import UIKit
import CoreLocation

class AddPinVC: UIViewController {
    
    let mapID = "showMap"
    
    var activeTextField: UITextField?
    var Locationcoordinate: CLLocationCoordinate2D!
    
    @IBOutlet weak var locationField: UITextField!
    @IBOutlet weak var urlField: UITextField!
    @IBOutlet weak var showButton: UIButton!
    @IBOutlet weak var cancelButton: UIBarButtonItem!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationField.delegate = self
        urlField.delegate = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        subscribeToKeyboardNotifications()
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        unsubscribeFromKeyboardNotifications()
    }
    
    @IBAction func showButtonClicked(_ sender: Any) {
        enableUI(false)
        let url = URL(string: urlField.text!)
        guard url != nil else {
            Helpers.showAlertDialog(viewController: self, title: "Error", message: "Invalid Link (URL)")
            enableUI(true)
            return
        }
        getCoordinate(addressString: locationField.text!) { (coordinate, error) in
            self.enableUI(true)
            if let error = error {
                Helpers.showAlertDialog(viewController: self, title: "Invalid Location", message: error.localizedDescription)
                return
            }
            self.Locationcoordinate = coordinate
            self.performSegue(withIdentifier: self.mapID, sender: self)
        }
    }
    
    
    @IBAction func cancelButtonClicked(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
      }
    
    
    func enableUI(_ enabled: Bool) {
        
        DispatchQueue.main.async {
            self.locationField.isEnabled = enabled
            self.urlField.isEnabled = enabled
            self.showButton.isEnabled = enabled
            self.cancelButton.isEnabled = enabled
            enabled ? self.activityIndicator.stopAnimating() :
                self.activityIndicator.startAnimating()
            
        }
    }
    
    func getCoordinate(addressString : String,
                        completionHandler: @escaping(CLLocationCoordinate2D, NSError?) -> Void) {
        let geocoder = CLGeocoder()
        geocoder.geocodeAddressString(addressString) { (placemarks, error) in
            if error == nil {
                if let placemark = placemarks?[0] {
                    let location = placemark.location!
                    completionHandler(location.coordinate, nil)
                    return
                }
            }
            completionHandler(kCLLocationCoordinate2DInvalid, error as NSError?)
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == mapID {
            let vc = segue.destination as! ShareVC
            vc.Locationcoordinate = Locationcoordinate
            vc.mediaURL = urlField.text!
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        view.endEditing(true)
    }
    
    
}


extension AddPinVC{
    
    func subscribeToKeyboardNotifications() {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    func unsubscribeFromKeyboardNotifications() {
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    @objc func keyboardWillShow(_ notification:Notification) {
        if activeTextField == urlField {
            view.frame.origin.y -= 100//getKeyboardHeight(notification)
        }
    }
    
    @objc func keyboardWillHide(_ notification:Notification) {
        view.frame.origin.y = 0
    }
    
    func getKeyboardHeight(_ notification:Notification) -> CGFloat {
        let userInfo = notification.userInfo
        let keyboardSize = userInfo![UIResponder.keyboardFrameEndUserInfoKey] as! NSValue
        return keyboardSize.cgRectValue.height
    }
}
    

extension AddPinVC: UITextFieldDelegate {
    func textFieldDidBeginEditing(_ textField: UITextField) {
        activeTextField = textField
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        activeTextField = nil
        textField.resignFirstResponder()
        return true
    }
}

