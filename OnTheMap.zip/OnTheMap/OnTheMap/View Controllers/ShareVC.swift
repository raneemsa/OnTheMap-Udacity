//
//  ShareVC.swift
//  OnTheMap
//
//  Created by Raneem on 5/8/19.
//  Copyright © 2019 Raneem. All rights reserved.
//

import UIKit
import MapKit

class ShareVC: UIViewController {

    @IBOutlet weak var mapView: MKMapView!
    
    var Locationcoordinate: CLLocationCoordinate2D!
    var mediaURL: String!
    var onMapLableString: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        mapView.delegate = self
        let firstName = NetworkManager.Udacity.user?.firstName
        let lastName = NetworkManager.Udacity.user?.lastName
        onMapLableString = "\(firstName ?? "") \(lastName ?? "")"
        if onMapLableString == " " {
            onMapLableString = NetworkManager.Udacity.user?.nickname ?? "-NONE-"
        }
        
        let annotation = MKPointAnnotation()
        annotation.coordinate = Locationcoordinate
        annotation.title = onMapLableString
        annotation.subtitle = mediaURL
        mapView.addAnnotation(annotation)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        let region = MKCoordinateRegion(center: Locationcoordinate, latitudinalMeters: 200, longitudinalMeters: 200)
        mapView.setRegion(region, animated: false)
    }
    
    @IBAction func DoneButtonClicked(_ sender: Any) {
        NetworkManager.Parse.setStudentLocation(mapString: onMapLableString, mediaURL: mediaURL, latitude: Float(Locationcoordinate.latitude), longitude: Float(Locationcoordinate.longitude)) { (errorMessage) in
            if let error = errorMessage {
                Helpers.showAlertDialog(viewController: self, title: "Failed to submit Pin", message: error)
            }
            else {
                self.navigationController?.viewControllers[0].dismiss(animated: true, completion: nil)
            }
        }
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        view.endEditing(true)
    }
    

}

extension ShareVC: MKMapViewDelegate {

    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        let reuseId = "pin"
        
        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView
        
        if pinView == nil {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            pinView!.canShowCallout = true
            pinView!.pinTintColor = .red
            pinView!.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
        }
        else {
            pinView!.annotation = annotation
        }
        
        return pinView
    }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        if control == view.rightCalloutAccessoryView {
            let app = UIApplication.shared
            if let toOpen = view.annotation?.subtitle! {
                app.open(URL(string: toOpen)!, options: [:], completionHandler: nil)
            }
        }
    }
    
}
