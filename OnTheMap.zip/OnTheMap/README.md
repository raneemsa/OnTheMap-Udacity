# On The Map
This app allows users to share their location and a URL with their fellow students. To visualize this data, On The Map uses a map with pins for location and pin annotations for student names and URLs, allowing students to place themselves “on the map”.
Implementing this project was a part of my "iOS Developer Nanodegree" at Udacity.
# 🖼️ Screenshots

| <img src="https://i.imgur.com/QNdg6c0.png" width="300"> | <img src="https://i.imgur.com/SC6tpNi.png" width="300"> |
| ------------------------------------------------------- | ------------------------------------------------------- |
| <img src="https://i.imgur.com/KaRptJr.png" width="300"> |
# Disclaimer
Using this project in your "iOS Developer Nanodegree" will be considered as plagiarism, and it will lead to disqualifying you from the nanodegree.
